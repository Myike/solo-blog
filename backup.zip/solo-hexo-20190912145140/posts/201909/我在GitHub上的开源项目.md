title: 我在 GitHub 上的开源项目
date: '2019-09-12 14:41:38'
updated: '2019-09-12 14:41:38'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [wxapp](https://github.com/wuaixia/wxapp) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/wuaixia/wxapp/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/wuaixia/wxapp/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wuaixia/wxapp/network/members "分叉数")</span>

微信小程序



---

### 2. [short-url](https://github.com/wuaixia/short-url) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/wuaixia/short-url/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/wuaixia/short-url/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/wuaixia/short-url/network/members "分叉数")</span>

JAVA短域名实现-整套项目



---

### 3. [JD](https://github.com/wuaixia/JD) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/wuaixia/JD/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/wuaixia/JD/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/wuaixia/JD/network/members "分叉数")</span>

京东首页前端模仿demo

